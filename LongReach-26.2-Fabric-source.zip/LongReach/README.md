# Long Reach — Minecraft 26.2 Fabric

A small Fabric mod that sets both vanilla player interaction ranges to **8 blocks**:

- Block interaction range: 8.0 blocks
- Entity interaction range: 8.0 blocks

## Compatibility

- Minecraft Java Edition 26.2
- Fabric Loader 0.19.3+
- Fabric API 0.155.0+26.2+
- Java 25 for building

## Important multiplayer note

The mod changes the player's attributes on the **server side**. For a multiplayer server, the server needs the mod too. Installing it only on the client will not make a vanilla server accept extended-range interactions.

## Change the reach

Edit `REACH` in:

`src/main/java/com/wafis/longreach/LongReach.java`

For example, change `8.0D` to `12.0D`.

## Build

Use JDK 25 and run:

`./gradlew build`

The built JAR will be in `build/libs/`.
